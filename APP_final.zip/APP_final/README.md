# University Lost & Found (JavaFX + MySQL)

A modern desktop app for students to report lost/found items, search, and manage claims. Built with Java 17, JavaFX, MySQL, HikariCP, and CSS styling.

## Features
- User registration and login (bcrypt hashed)
- Report lost and found items with image path
- Search and filter by text, category, and status
- Claim workflow (submit, approve, reject)
- Role support (Student, Admin seed)
- Responsive JavaFX UI with CSS theme

## Requirements
- Java 17 (Temurin recommended)
- Maven 3.9+
- Windows PowerShell (for commands below)

## Setup
1. Create local SQLite DB file and tables (runs automatically on first use with schema, or execute manually):
   - Run the app once or execute `src/main/resources/sql/schema.sql` in any SQLite tool.
2. Configure DB (already set to SQLite by default):
   - `src/main/resources/application.properties`:
     ```
     db.url=jdbc:sqlite:unilostfound.db
     ```
3. Build and run:
   ```powershell
   mvn -q clean javafx:run
   ```

## Admin Login
- Email: `admin@university.edu`
- Password: `admin` (seeded hash)

## Project Structure
- `src/main/java/com/unilostfound` - App entry point
- `core` - Router & Config
- `db` - HikariCP pool
- `dao` - DAO interfaces
- `dao/mysql` - MySQL implementations
- `model` - Domain models
- `service` - Auth, Items, Claims
- `ui` - Controllers
- `resources/fxml` - FXML Views
- `resources/styles` - CSS theme
- `resources/sql` - Schema and seed

## Notes
- Image handling uses file path for simplicity; extend to copy uploads into an app folder as needed.
- Add advanced features like moderation queue, CSV export, and email notifications by extending services and adding views.



