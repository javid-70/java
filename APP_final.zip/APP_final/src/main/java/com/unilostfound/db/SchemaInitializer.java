package com.unilostfound.db;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.Statement;

public class SchemaInitializer {
    public static void ensureSchema() {
        try (Connection c = Database.getConnection()) {
            // Try a quick check
            try (Statement s = c.createStatement()) {
                s.execute("SELECT 1 FROM users LIMIT 1");
                return; // table exists
            } catch (Exception ignored) {
                // will apply schema
            }

            try (InputStream in = SchemaInitializer.class.getResourceAsStream("/sql/schema.sql")) {
                if (in == null) return;
                try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                     Statement stmt = c.createStatement()) {
                    StringBuilder current = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        String trimmed = line.trim();
                        if (trimmed.isEmpty() || trimmed.startsWith("--")) continue;
                        current.append(line).append('\n');
                        if (trimmed.endsWith(";")) {
                            String sql = current.toString().trim();
                            // remove trailing semicolon for SQLite JDBC
                            if (sql.endsWith(";")) sql = sql.substring(0, sql.length() - 1);
                            if (!sql.isBlank()) stmt.execute(sql);
                            current.setLength(0);
                        }
                    }
                    // execute any remaining statement without semicolon
                    String leftover = current.toString().trim();
                    if (!leftover.isBlank()) stmt.execute(leftover);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize schema", e);
        }
    }
}


