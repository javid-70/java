package com.unilostfound.service;

import com.unilostfound.dao.ItemDao;
import com.unilostfound.dao.sqlite.SqliteItemDao;
import com.unilostfound.model.Item;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public class ItemService {
    private static final ItemService INSTANCE = new ItemService();
    private final ItemDao itemDao = new SqliteItemDao();

    public static ItemService getInstance() { return INSTANCE; }

    public long reportLost(String title, String description, String category, String location, String imagePath, long userId) {
        Item item = new Item();
        item.setTitle(title);
        item.setDescription(description);
        item.setCategory(category);
        item.setLocation(location);
        item.setImagePath(imagePath);
        item.setStatus(Item.Status.LOST);
        item.setReporterUserId(userId);
        item.setReportedAt(LocalDateTime.now());
        return itemDao.create(item);
    }

    public long reportFound(String title, String description, String category, String location, String imagePath, long userId) {
        Item item = new Item();
        item.setTitle(title);
        item.setDescription(description);
        item.setCategory(category);
        item.setLocation(location);
        item.setImagePath(imagePath);
        item.setStatus(Item.Status.FOUND);
        item.setReporterUserId(userId);
        item.setReportedAt(LocalDateTime.now());
        return itemDao.create(item);
    }

    public Optional<Item> get(long id) { return itemDao.findById(id); }
    public List<Item> latest(int limit) { return itemDao.latest(limit); }
    public List<Item> search(String q, String category, Item.Status status, int offset, int limit) { return itemDao.search(q, category, status, offset, limit); }
}



