package com.unilostfound.service;

import com.unilostfound.dao.UserDao;
import com.unilostfound.dao.sqlite.SqliteUserDao;
import com.unilostfound.model.User;
import org.mindrot.jbcrypt.BCrypt;

import java.util.Optional;

public class AuthService {
    private static final AuthService INSTANCE = new AuthService();
    private final UserDao userDao = new SqliteUserDao();
    private User currentUser;

    public static AuthService getInstance() { return INSTANCE; }

    public User register(String fullName, String email, String password) {
        String hash = BCrypt.hashpw(password, BCrypt.gensalt());
        User u = new User();
        u.setFullName(fullName);
        u.setEmail(email.toLowerCase());
        u.setPasswordHash(hash);
        u.setRole(User.Role.STUDENT);
        long id = userDao.create(u);
        u.setId(id);
        currentUser = u;
        return u;
    }

    public boolean login(String email, String password) {
        Optional<User> userOpt = userDao.findByEmail(email.toLowerCase());
        if (userOpt.isPresent()) {
            User u = userOpt.get();
            if (BCrypt.checkpw(password, u.getPasswordHash())) {
                currentUser = u;
                return true;
            }
        }
        return false;
    }

    public void logout() { currentUser = null; }
    public boolean isAuthenticated() { return currentUser != null; }
    public User getCurrentUser() { return currentUser; }
}



