package com.unilostfound.service;

import com.unilostfound.dao.ClaimDao;
import com.unilostfound.dao.ItemDao;
import com.unilostfound.dao.sqlite.SqliteClaimDao;
import com.unilostfound.dao.sqlite.SqliteItemDao;
import com.unilostfound.model.Claim;
import com.unilostfound.model.Item;

import java.time.LocalDateTime;
import java.util.List;

public class ClaimService {
    private static final ClaimService INSTANCE = new ClaimService();
    private final ClaimDao claimDao = new SqliteClaimDao();
    private final ItemDao itemDao = new SqliteItemDao();

    public static ClaimService getInstance() { return INSTANCE; }

    public long submitClaim(long itemId, long userId, String message) {
        Claim c = new Claim();
        c.setItemId(itemId);
        c.setClaimantUserId(userId);
        c.setMessage(message);
        c.setStatus(Claim.Status.PENDING);
        c.setCreatedAt(LocalDateTime.now());
        return claimDao.create(c);
    }

    public void approveClaim(long claimId) {
        claimDao.updateStatus(claimId, Claim.Status.APPROVED);
        claimDao.findById(claimId).ifPresent(c -> itemDao.findById(c.getItemId()).ifPresent(item -> {
            item.setStatus(Item.Status.CLAIMED);
            itemDao.update(item);
        }));
    }

    public void rejectClaim(long claimId) { claimDao.updateStatus(claimId, Claim.Status.REJECTED); }
    public List<Claim> listByItem(long itemId) { return claimDao.listByItem(itemId); }
    public List<Claim> listByUser(long userId) { return claimDao.listByUser(userId); }
    public List<Claim> listPending() { return claimDao.listPending(); }
}



