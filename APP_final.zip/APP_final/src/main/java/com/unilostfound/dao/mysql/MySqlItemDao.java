package com.unilostfound.dao.mysql;

import com.unilostfound.dao.ItemDao;
import com.unilostfound.db.Database;
import com.unilostfound.model.Item;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MySqlItemDao implements ItemDao {
    @Override
    public long create(Item item) {
        String sql = "INSERT INTO items(title,description,category,location,image_path,status,reporter_user_id,reported_at) VALUES(?,?,?,?,?,?,?,?)";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, item.getTitle());
            ps.setString(2, item.getDescription());
            ps.setString(3, item.getCategory());
            ps.setString(4, item.getLocation());
            ps.setString(5, item.getImagePath());
            ps.setString(6, item.getStatus().name());
            ps.setLong(7, item.getReporterUserId());
            ps.setTimestamp(8, Timestamp.valueOf(item.getReportedAt() != null ? item.getReportedAt() : LocalDateTime.now()));
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) { if (rs.next()) return rs.getLong(1); }
        } catch (SQLException e) { throw new RuntimeException(e); }
        throw new RuntimeException("Failed to insert item");
    }

    @Override
    public void update(Item item) {
        String sql = "UPDATE items SET title=?,description=?,category=?,location=?,image_path=?,status=? WHERE id=?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, item.getTitle());
            ps.setString(2, item.getDescription());
            ps.setString(3, item.getCategory());
            ps.setString(4, item.getLocation());
            ps.setString(5, item.getImagePath());
            ps.setString(6, item.getStatus().name());
            ps.setLong(7, item.getId());
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    @Override
    public Optional<Item> findById(long id) {
        String sql = "SELECT * FROM items WHERE id=?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return Optional.of(map(rs)); }
        } catch (SQLException e) { throw new RuntimeException(e); }
        return Optional.empty();
    }

    @Override
    public List<Item> search(String query, String category, Item.Status status, int offset, int limit) {
        StringBuilder sb = new StringBuilder("SELECT * FROM items WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (query != null && !query.isBlank()) { sb.append(" AND (title LIKE ? OR description LIKE ? OR location LIKE ?)"); String q = "%" + query + "%"; params.add(q); params.add(q); params.add(q); }
        if (category != null && !category.isBlank()) { sb.append(" AND category=?"); params.add(category); }
        if (status != null) { sb.append(" AND status=?"); params.add(status.name()); }
        sb.append(" ORDER BY reported_at DESC LIMIT ? OFFSET ?"); params.add(limit); params.add(offset);
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sb.toString())) {
            for (int i = 0; i < params.size(); i++) ps.setObject(i + 1, params.get(i));
            try (ResultSet rs = ps.executeQuery()) {
                List<Item> list = new ArrayList<>();
                while (rs.next()) list.add(map(rs));
                return list;
            }
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    @Override
    public List<Item> latest(int limit) {
        String sql = "SELECT * FROM items ORDER BY reported_at DESC LIMIT ?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                List<Item> list = new ArrayList<>();
                while (rs.next()) list.add(map(rs));
                return list;
            }
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    private Item map(ResultSet rs) throws SQLException {
        Item i = new Item();
        i.setId(rs.getLong("id"));
        i.setTitle(rs.getString("title"));
        i.setDescription(rs.getString("description"));
        i.setCategory(rs.getString("category"));
        i.setLocation(rs.getString("location"));
        i.setImagePath(rs.getString("image_path"));
        i.setStatus(Item.Status.valueOf(rs.getString("status")));
        i.setReporterUserId(rs.getLong("reporter_user_id"));
        Timestamp ts = rs.getTimestamp("reported_at");
        if (ts != null) i.setReportedAt(ts.toLocalDateTime());
        return i;
    }
}



