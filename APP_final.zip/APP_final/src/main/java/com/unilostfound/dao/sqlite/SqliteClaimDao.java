package com.unilostfound.dao.sqlite;

import com.unilostfound.dao.ClaimDao;
import com.unilostfound.db.Database;
import com.unilostfound.model.Claim;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SqliteClaimDao implements ClaimDao {
    @Override
    public long create(Claim claim) {
        String sql = "INSERT INTO claims(item_id,claimant_user_id,message,status,created_at) VALUES(?,?,?,?,?)";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, claim.getItemId());
            ps.setLong(2, claim.getClaimantUserId());
            ps.setString(3, claim.getMessage());
            ps.setString(4, claim.getStatus().name());
            ps.setTimestamp(5, Timestamp.valueOf(claim.getCreatedAt() != null ? claim.getCreatedAt() : LocalDateTime.now()));
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) { if (rs.next()) return rs.getLong(1); }
        } catch (SQLException e) { throw new RuntimeException(e); }
        throw new RuntimeException("Failed to insert claim");
    }

    @Override
    public void updateStatus(long claimId, Claim.Status status) {
        String sql = "UPDATE claims SET status=? WHERE id=?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status.name());
            ps.setLong(2, claimId);
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    @Override
    public List<Claim> listByItem(long itemId) {
        String sql = "SELECT * FROM claims WHERE item_id=? ORDER BY created_at DESC";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, itemId);
            try (ResultSet rs = ps.executeQuery()) { return mapList(rs); }
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    @Override
    public List<Claim> listByUser(long userId) {
        String sql = "SELECT * FROM claims WHERE claimant_user_id=? ORDER BY created_at DESC";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) { return mapList(rs); }
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    @Override
    public Optional<Claim> findById(long id) {
        String sql = "SELECT * FROM claims WHERE id=?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return Optional.of(map(rs)); }
        } catch (SQLException e) { throw new RuntimeException(e); }
        return Optional.empty();
    }

    @Override
    public List<Claim> listPending() {
        String sql = "SELECT * FROM claims WHERE status='PENDING' ORDER BY created_at ASC";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            try (ResultSet rs = ps.executeQuery()) { return mapList(rs); }
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    private List<Claim> mapList(ResultSet rs) throws SQLException {
        List<Claim> list = new ArrayList<>();
        while (rs.next()) list.add(map(rs));
        return list;
    }

    private Claim map(ResultSet rs) throws SQLException {
        Claim c = new Claim();
        c.setId(rs.getLong("id"));
        c.setItemId(rs.getLong("item_id"));
        c.setClaimantUserId(rs.getLong("claimant_user_id"));
        c.setMessage(rs.getString("message"));
        c.setStatus(Claim.Status.valueOf(rs.getString("status")));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) c.setCreatedAt(ts.toLocalDateTime());
        return c;
    }
}


