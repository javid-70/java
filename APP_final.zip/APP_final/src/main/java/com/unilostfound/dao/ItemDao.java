package com.unilostfound.dao;

import com.unilostfound.model.Item;
import java.util.List;
import java.util.Optional;

public interface ItemDao {
    long create(Item item);
    void update(Item item);
    Optional<Item> findById(long id);
    List<Item> search(String query, String category, Item.Status status, int offset, int limit);
    List<Item> latest(int limit);
}



