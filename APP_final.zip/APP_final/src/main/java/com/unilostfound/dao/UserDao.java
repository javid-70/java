package com.unilostfound.dao;

import com.unilostfound.model.User;
import java.util.Optional;

public interface UserDao {
    long create(User user);
    Optional<User> findByEmail(String email);
    Optional<User> findById(long id);
}



