package com.unilostfound.dao;

import com.unilostfound.model.Claim;
import java.util.List;
import java.util.Optional;

public interface ClaimDao {
    long create(Claim claim);
    void updateStatus(long claimId, Claim.Status status);
    List<Claim> listByItem(long itemId);
    List<Claim> listByUser(long userId);
    Optional<Claim> findById(long id);
    List<Claim> listPending();
}


