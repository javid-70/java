package com.unilostfound.ui;

import com.unilostfound.core.Router;
import com.unilostfound.model.Item;
import com.unilostfound.service.AuthService;
import com.unilostfound.service.ClaimService;
import com.unilostfound.service.ItemService;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ItemDetailsController {
    @FXML private Label titleLabel;
    @FXML private Label categoryLabel;
    @FXML private Label statusLabel;
    @FXML private Label locationLabel;
    @FXML private TextArea descriptionArea;
    @FXML private ImageView imageView;
    @FXML private TextArea claimMessage;

    private final ItemService items = ItemService.getInstance();
    private final ClaimService claims = ClaimService.getInstance();
    private final AuthService auth = AuthService.getInstance();
    private long itemId;

    public void setItemId(long itemId) {
        this.itemId = itemId;
        items.get(itemId).ifPresent(this::render);
    }

    private void render(Item i) {
        titleLabel.setText(i.getTitle());
        categoryLabel.setText(i.getCategory());
        statusLabel.setText(i.getStatus().name());
        locationLabel.setText(i.getLocation());
        descriptionArea.setText(i.getDescription());
        if (i.getImagePath() != null && !i.getImagePath().isBlank()) {
            try { imageView.setImage(new Image("file:" + i.getImagePath(), true)); } catch (Exception ignored) {}
        }
    }

    @FXML
    public void submitClaim() {
        if (!auth.isAuthenticated()) { new Alert(Alert.AlertType.ERROR, "Please login").showAndWait(); return; }
        String msg = claimMessage.getText();
        if (msg == null || msg.isBlank()) { new Alert(Alert.AlertType.WARNING, "Please describe proof of ownership").showAndWait(); return; }
        claims.submitClaim(itemId, auth.getCurrentUser().getId(), msg);
        new Alert(Alert.AlertType.INFORMATION, "Claim submitted for review").showAndWait();
        goBack();
    }

    @FXML
    public void goBack() {
        Scene s = Router.getInstance().navigateTo("/fxml/DashboardView.fxml");
        ((javafx.stage.Stage) titleLabel.getScene().getWindow()).setScene(s);
    }
}



