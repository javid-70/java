package com.unilostfound.ui;

import com.unilostfound.core.Router;
import com.unilostfound.service.AuthService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;

public class LoginController {
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;

    private final AuthService auth = AuthService.getInstance();

    @FXML
    public void onLogin(ActionEvent e) {
        String email = emailField.getText();
        String pass = passwordField.getText();
        if (auth.login(email, pass)) {
            Scene s = Router.getInstance().navigateTo("/fxml/DashboardView.fxml");
            ((javafx.stage.Stage) emailField.getScene().getWindow()).setScene(s);
        } else {
            Alert a = new Alert(Alert.AlertType.ERROR, "Invalid email or password");
            a.showAndWait();
        }
    }

    @FXML
    public void goRegister(ActionEvent e) {
        Scene s = Router.getInstance().navigateTo("/fxml/RegisterView.fxml");
        ((javafx.stage.Stage) emailField.getScene().getWindow()).setScene(s);
    }
}



