package com.unilostfound.ui;

import com.unilostfound.core.Router;
import com.unilostfound.service.AuthService;
import com.unilostfound.service.ItemService;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;

public class ReportFoundController {
    @FXML private TextField titleField;
    @FXML private ChoiceBox<String> categoryChoice;
    @FXML private TextField locationField;
    @FXML private TextArea descriptionArea;
    @FXML private TextField imageField;

    private final ItemService items = ItemService.getInstance();
    private final AuthService auth = AuthService.getInstance();

    @FXML
    public void initialize() {
        categoryChoice.setItems(FXCollections.observableArrayList("Electronics","Accessories","ID Cards","Clothing","Other"));
        categoryChoice.getSelectionModel().selectFirst();
    }

    @FXML
    public void onSubmit(ActionEvent e) {
        if (!auth.isAuthenticated()) { new Alert(Alert.AlertType.ERROR, "Please login").showAndWait(); return; }
        String title = titleField.getText();
        if (title.isBlank()) { new Alert(Alert.AlertType.WARNING, "Title is required").showAndWait(); return; }
        items.reportFound(title, descriptionArea.getText(), categoryChoice.getValue(), locationField.getText(), imageField.getText(), auth.getCurrentUser().getId());
        new Alert(Alert.AlertType.INFORMATION, "Found item reported").showAndWait();
        goBack(null);
    }

    @FXML
    public void goBack(ActionEvent e) {
        Scene s = Router.getInstance().navigateTo("/fxml/DashboardView.fxml");
        ((javafx.stage.Stage) titleField.getScene().getWindow()).setScene(s);
    }
}



