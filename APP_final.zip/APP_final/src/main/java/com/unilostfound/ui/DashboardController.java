package com.unilostfound.ui;

import com.unilostfound.core.Router;
import com.unilostfound.model.Item;
import com.unilostfound.service.AuthService;
import com.unilostfound.service.ItemService;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class DashboardController {
    @FXML private TextField searchField;
    @FXML private ChoiceBox<String> categoryChoice;
    @FXML private ChoiceBox<String> statusChoice;
    @FXML private TableView<Item> itemsTable;
    @FXML private TableColumn<Item, String> colTitle;
    @FXML private TableColumn<Item, String> colCategory;
    @FXML private TableColumn<Item, String> colStatus;
    @FXML private TableColumn<Item, String> colLocation;
    @FXML private TableColumn<Item, String> colReportedAt;

    private final ItemService items = ItemService.getInstance();
    private final AuthService auth = AuthService.getInstance();

    @FXML
    public void initialize() {
        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        colCategory.setCellValueFactory(new PropertyValueFactory<>("category"));
        colStatus.setCellValueFactory(c -> javafx.beans.binding.Bindings.createStringBinding(() -> c.getValue().getStatus().name()));
        colLocation.setCellValueFactory(new PropertyValueFactory<>("location"));
        colReportedAt.setCellValueFactory(c -> javafx.beans.binding.Bindings.createStringBinding(() -> String.valueOf(c.getValue().getReportedAt())));

        categoryChoice.setItems(FXCollections.observableArrayList("All","Electronics","Accessories","ID Cards","Clothing","Other"));
        categoryChoice.getSelectionModel().selectFirst();
        statusChoice.setItems(FXCollections.observableArrayList("All","LOST","FOUND","CLAIMED"));
        statusChoice.getSelectionModel().selectFirst();

        itemsTable.setItems(FXCollections.observableArrayList(items.latest(50)));
        itemsTable.setOnMouseClicked(ev -> {
            if (ev.getClickCount() == 2 && itemsTable.getSelectionModel().getSelectedItem() != null) {
                Item sel = itemsTable.getSelectionModel().getSelectedItem();
                // Load details view and set itemId
                var loader = new javafx.fxml.FXMLLoader(getClass().getResource("/fxml/ItemDetailsView.fxml"));
                try {
                    javafx.scene.Parent root = loader.load();
                    var ctrl = (ItemDetailsController) loader.getController();
                    ctrl.setItemId(sel.getId());
                    ((javafx.stage.Stage) itemsTable.getScene().getWindow()).setScene(Router.getInstance().createScene(root));
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
    }

    @FXML
    public void onSearch(ActionEvent e) {
        String q = searchField.getText();
        String cat = categoryChoice.getValue();
        String stat = statusChoice.getValue();
        Item.Status s = ("All".equals(stat) ? null : Item.Status.valueOf(stat));
        String category = ("All".equals(cat) ? null : cat);
        itemsTable.setItems(FXCollections.observableArrayList(items.search(q, category, s, 0, 200)));
    }

    @FXML
    public void goReportLost(ActionEvent e) {
        Scene scene = Router.getInstance().navigateTo("/fxml/ReportLostView.fxml");
        ((javafx.stage.Stage) itemsTable.getScene().getWindow()).setScene(scene);
    }

    @FXML
    public void goReportFound(ActionEvent e) {
        Scene scene = Router.getInstance().navigateTo("/fxml/ReportFoundView.fxml");
        ((javafx.stage.Stage) itemsTable.getScene().getWindow()).setScene(scene);
    }

    @FXML
    public void logout(ActionEvent e) {
        auth.logout();
        Scene s = Router.getInstance().navigateTo("/fxml/LoginView.fxml");
        ((javafx.stage.Stage) itemsTable.getScene().getWindow()).setScene(s);
    }

    @FXML
    public void goAdmin(ActionEvent e) {
        if (auth.isAuthenticated() && auth.getCurrentUser().getRole() == com.unilostfound.model.User.Role.ADMIN) {
            Scene s = Router.getInstance().navigateTo("/fxml/AdminView.fxml");
            ((javafx.stage.Stage) itemsTable.getScene().getWindow()).setScene(s);
        } else {
            new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR, "Admin only").showAndWait();
        }
    }
}


