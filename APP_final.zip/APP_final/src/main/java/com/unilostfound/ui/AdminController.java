package com.unilostfound.ui;

import com.unilostfound.core.Router;
import com.unilostfound.model.Claim;
import com.unilostfound.service.ClaimService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class AdminController {
    @FXML private TableView<Claim> claimsTable;
    @FXML private TableColumn<Claim, Long> colId;
    @FXML private TableColumn<Claim, Long> colItemId;
    @FXML private TableColumn<Claim, Long> colUserId;
    @FXML private TableColumn<Claim, String> colMessage;
    @FXML private TableColumn<Claim, String> colCreated;

    private final ClaimService claims = ClaimService.getInstance();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colItemId.setCellValueFactory(new PropertyValueFactory<>("itemId"));
        colUserId.setCellValueFactory(new PropertyValueFactory<>("claimantUserId"));
        colMessage.setCellValueFactory(new PropertyValueFactory<>("message"));
        colCreated.setCellValueFactory(c -> javafx.beans.binding.Bindings.createStringBinding(() -> String.valueOf(c.getValue().getCreatedAt())));
        refresh();
    }

    private void refresh() {
        claimsTable.setItems(FXCollections.observableArrayList(claims.listPending()));
    }

    @FXML
    public void approve() {
        Claim sel = claimsTable.getSelectionModel().getSelectedItem();
        if (sel == null) { new Alert(Alert.AlertType.WARNING, "Select a claim").showAndWait(); return; }
        claims.approveClaim(sel.getId());
        refresh();
    }

    @FXML
    public void reject() {
        Claim sel = claimsTable.getSelectionModel().getSelectedItem();
        if (sel == null) { new Alert(Alert.AlertType.WARNING, "Select a claim").showAndWait(); return; }
        claims.rejectClaim(sel.getId());
        refresh();
    }

    @FXML
    public void goBack() {
        Scene s = Router.getInstance().navigateTo("/fxml/DashboardView.fxml");
        ((javafx.stage.Stage) claimsTable.getScene().getWindow()).setScene(s);
    }

    @FXML
    public void exportCsv() {
        try {
            java.io.File file = new java.io.File(System.getProperty("user.home"), "pending_claims.csv");
            try (java.io.PrintWriter pw = new java.io.PrintWriter(file, java.nio.charset.StandardCharsets.UTF_8)) {
                pw.println("id,itemId,claimantUserId,message,createdAt");
                for (Claim c : claimsTable.getItems()) {
                    String msg = c.getMessage() == null ? "" : c.getMessage().replace('\n', ' ').replace('"','\'');
                    pw.printf("%d,%d,%d,\"%s\",%s%n", c.getId(), c.getItemId(), c.getClaimantUserId(), msg, c.getCreatedAt());
                }
            }
            new Alert(Alert.AlertType.INFORMATION, "Exported to " + file.getAbsolutePath()).showAndWait();
        } catch (Exception ex) {
            new Alert(Alert.AlertType.ERROR, "Export failed: " + ex.getMessage()).showAndWait();
        }
    }
}


