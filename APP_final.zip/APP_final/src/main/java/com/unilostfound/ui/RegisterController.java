package com.unilostfound.ui;

import com.unilostfound.core.Router;
import com.unilostfound.service.AuthService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;

public class RegisterController {
    @FXML private TextField fullNameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;

    private final AuthService auth = AuthService.getInstance();

    @FXML
    public void onRegister(ActionEvent e) {
        String name = fullNameField.getText();
        String email = emailField.getText();
        String pass = passwordField.getText();
        if (name.isBlank() || email.isBlank() || pass.isBlank()) {
            new Alert(Alert.AlertType.WARNING, "Please fill all fields").showAndWait();
            return;
        }
        try {
            auth.register(name, email, pass);
            Scene s = Router.getInstance().navigateTo("/fxml/DashboardView.fxml");
            ((javafx.stage.Stage) fullNameField.getScene().getWindow()).setScene(s);
        } catch (Exception ex) {
            new Alert(Alert.AlertType.ERROR, "Registration failed: " + ex.getMessage()).showAndWait();
        }
    }

    @FXML
    public void goLogin(ActionEvent e) {
        Scene s = Router.getInstance().navigateTo("/fxml/LoginView.fxml");
        ((javafx.stage.Stage) fullNameField.getScene().getWindow()).setScene(s);
    }
}



