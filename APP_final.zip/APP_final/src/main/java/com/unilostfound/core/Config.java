package com.unilostfound.core;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Config {
    private static final Properties PROPS = new Properties();
    static {
        try (InputStream in = Config.class.getResourceAsStream("/application.properties")) {
            if (in != null) {
                PROPS.load(in);
            } else {
                throw new IllegalStateException("Missing application.properties");
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config", e);
        }
    }

    public static String get(String key) {
        return PROPS.getProperty(key);
    }
}



