package com.unilostfound.core;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class Router {
    private static final Router INSTANCE = new Router();
    private final String stylesheet = getClass().getResource("/styles/app.css").toExternalForm();

    public static Router getInstance() {
        return INSTANCE;
    }

    public Scene loadInitialScene() {
        Scene scene = new Scene(load("/fxml/LoginView.fxml"));
        scene.getStylesheets().add(stylesheet);
        return scene;
    }

    public Scene navigateTo(String fxmlPath) {
        Scene scene = new Scene(load(fxmlPath));
        scene.getStylesheets().add(stylesheet);
        return scene;
    }

    public Scene createScene(Parent root) {
        Scene scene = new Scene(root);
        scene.getStylesheets().add(stylesheet);
        return scene;
    }

    public Parent load(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            return loader.load();
        } catch (Exception e) {
            throw new RuntimeException("Failed to load FXML: " + fxmlPath, e);
        }
    }
}



