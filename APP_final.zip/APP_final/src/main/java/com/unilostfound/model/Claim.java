package com.unilostfound.model;

import java.time.LocalDateTime;

public class Claim {
    private long id;
    private long itemId;
    private long claimantUserId;
    private String message;
    private Status status; // PENDING, APPROVED, REJECTED
    private LocalDateTime createdAt;

    public enum Status { PENDING, APPROVED, REJECTED }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getItemId() { return itemId; }
    public void setItemId(long itemId) { this.itemId = itemId; }
    public long getClaimantUserId() { return claimantUserId; }
    public void setClaimantUserId(long claimantUserId) { this.claimantUserId = claimantUserId; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}



